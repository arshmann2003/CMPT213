package ca.myApp.model;

public class Course {
    public Course(int courseId, String catalogNumber) {
        this.courseId = courseId;
        this.catalogNumber = catalogNumber;
    }
    public Course(){

    }
    public int courseId;
    public String catalogNumber;
}
