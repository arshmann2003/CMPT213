package ca.myApp.model;

public class WatcherBody {
    public long deptId;
    public long courseId;
}
