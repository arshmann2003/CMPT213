package ca.myApp.model;

public class Department {
    public long deptId;
    public String name;

    public Department(long deptId, String name) {
        this.deptId = deptId;
        this.name = name;
    }
    public Department(){

    }
}
