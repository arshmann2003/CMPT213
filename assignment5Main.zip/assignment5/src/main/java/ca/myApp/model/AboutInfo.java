package ca.myApp.model;

public class AboutInfo {
    public String authorName;
    public String appName;

    public AboutInfo(String authorName, String appName) {
        this.authorName = authorName;
        this.appName = appName;
    }
}
