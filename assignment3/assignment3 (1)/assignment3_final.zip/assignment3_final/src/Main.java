import view.TextUi;

/**
 * Main driver to begin inventory application
 */

public class Main {
    public static void main(String[] args){
        TextUi ui = new TextUi();
        ui.start();
    }
}