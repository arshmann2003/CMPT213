package ca.myApp.controllers;

import ca.myApp.model.AboutInfo;
import ca.myApp.model.CsvParser;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
class Controller {
    @GetMapping("/api/about")
    public AboutInfo getAboutInfo(){
        return new AboutInfo("Arsh Mann", "The Course Planner");
    }

    @GetMapping("/api/dump-model")
    public void displayAllCourses(){
        CsvParser parser = new CsvParser("data/course_data_2018.csv", ",");
        parser.parseFile();
        parser.displayData();
    }
}
