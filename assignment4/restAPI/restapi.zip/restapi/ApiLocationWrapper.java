package distribute.restapi;

public class ApiLocationWrapper {
    public int x;
    public int y;

}
